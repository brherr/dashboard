**Instructions**

    - Open index.html file in browser
    - Or, use VS Code live server extention
    - Or, open with browser based server

**Notes**

    Due to my lack of experience with web components (I'm most comfortable w/ React), this was a HUGE learning experience for me and I learned ALOT. I spent more time learning and researching beforehand than I did actually writing code, and I'm not afraid to admit that StackOverflow was my best friend during this assessment.

    One major thing to note is that during my research it seemed that if I used shadow DOM the scripts in test-1_page.html would not have access to the imported elements so the html was appended directly to the body.

    I know it's not perfect but with all of the things I learned building this, I consider it a success!
