// define custom element collection
class ElementCollection extends Array {
  closest(selector) {
    // pass selector to element method
    return this.map((el) => el.closest(selector));
  }

  /*
      set event callback for element; set for all children matching
    
  */
  on(event, selector = undefined, callback) {
    // add event listener to each element passed
    this.forEach((el) => {
      el.addEventListener(event, (e) => {
        if (selector) {
          if (e.target.matches(selector)) callback(e);
        } else {
          callback(e);
        }
      });
    });
  }

  ready(callback) {
    // check if any elements are done loading
    const isReady = this.some(
      (element) => element.readyState !== null && e.readyState !== "loading"
    );

    // if document is ready, execute callback, else execute on event
    if (isReady) {
      callback();
    } else {
      this.on("DOMContentLoaded", callback);
    }
  }

  /*
      remove element attribute
  */
  removeAttr(attribute) {
    // pass attribute to element method
    this.forEach((el) => el.removeAttribute(attribute));
  }

  /*
      get or set element text content
      indexed into array for return value as quick fix for use case
      
    */
  text(newTextContent) {
    if (newTextContent) {
      this.forEach((el) => (el.textContent = `${newTextContent}`));
    } else {
      return this.map((el) => el.textContent)[0];
    }
  }

  // toggle visibility of a list of elements

  toggle() {
    const display = this[0].style.display;

    this.forEach((el) => {
      el.style.display = display === "none" ? null : "none";
    });
  }

  /*
      add or remove specified class(es) depending on whether they are absent
      or present 
  */
  toggleClass(classes) {
    const classNames = classes.split(" ");
    // update class list for each element
    this.forEach((el) => {
      classNames.forEach((className) => {
        const elClasses = el.className.split(" ");

        if (elClasses.includes(className)) {
          el.classList.remove(className);
        } else {
          el.classList.add(className);
        }
      });
    });
  }
}

function $(selectorOrElement) {
  if (typeof selectorOrElement === "string") {
    return new ElementCollection(
      ...document.querySelectorAll(selectorOrElement)
    );
  } else {
    return new ElementCollection(selectorOrElement);
  }
}
