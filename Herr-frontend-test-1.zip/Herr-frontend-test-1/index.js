// define custom html element
class ArrayCreditLock extends HTMLElement {
  constructor() {
    super();

    this.src = this.getAttribute("src");
    this.dataSrc = this.getAttribute("dataSrc");

    this._template = document.createElement("template");

    this.expanded = false;
  }

  async connectedCallback() {
    try {
      // fetch html source code
      this._template.innerHTML = await this._getSourceHTML(this.src);
      this._htmlContent = this._template.content.cloneNode(true);

      // store references to relevant elements
      this._showAllBtn = this._htmlContent.querySelector(".show-all");
      this._lockWrapper = this._htmlContent.querySelector(".lock-wrapper");
      this._historyList = this._htmlContent.querySelector(
        ".history-title + ul"
      );

      // using a shadow dom would make children inaccessible to external scripts
      this._historyList.replaceChildren();
      this._createTemplate();

      this.data = await this._fetchData();
      this._populateTemplate(this.data);

      // add list item count and onClick handler to "show-all" button
      // bind to class to make props accessible
      this._showAllBtn.textContent = `Show All (${this.data.length})`;
      this._showAllBtn.addEventListener("click", this._toggleExpand.bind(this));
    } catch (err) {
      // display error message if page fails to load
      const errorMessage = document.createElement("p");
      errorMessage.textContent = err.message;
      document.body.prepend(errorMessage);
    }
  }

  _cloneScriptTag(scriptTag) {
    // create new script tag and extract key values from existing tag
    const tag = document.createElement("script");
    const src = scriptTag.getAttribute("src");
    const textContent = scriptTag.textContent;

    if (src) {
      // if code is imported, set new tag src and add to document
      tag.setAttribute("src", src);
      document.body.append(tag);
    }

    if (textContent) {
      // if code is enclosed, set new tag textContent
      tag.textContent = textContent;

      (() => {
        const loadingInterval = setInterval(() => {
          if (window.utils) {
            // if loaded, add new tag to body
            document.body.append(tag);
            clearInterval(loadingInterval);
          }
        }, 10);
      })();
    }

    // remove old script tag
    this._htmlContent.removeChild(scriptTag);
  }

  // create a history list item using provided values

  _createListItem({ provider, type, date, active }) {
    const listElem = document.createElement("li");
    listElem.classList.add("history-list");

    // create an array of children
    const children = [
      this._createSpan("provider", provider),
      this._createSpan("type", type),
      this._createSpan("date", this._formatDate(date)),
      this._createLock(active),
    ];

    // append each child element to new list element
    children.forEach((child) => {
      listElem.append(child);
    });

    return listElem;
  }

  _createSpan(className, textContent) {
    const span = document.createElement("span");
    span.classList.add(className);
    span.textContent = textContent;
    return span;
  }

  _createLock(active) {
    const lockWrapper = this._lockWrapper.cloneNode(true);
    const lockedStatus = lockWrapper.querySelector(".lock");
    lockedStatus.textContent = active ? "Unlocked" : "Locked";
    return lockWrapper;
  }

  _createTemplate() {
    // get all script tags in source html
    const scripts = this._htmlContent.querySelectorAll("script");

    if (!scripts) {
      throw new Error("404: page could not be found");
    }

    // clone to new script tag
    // bind callback to class scope to access _htmlContent
    scripts.forEach(this._cloneScriptTag.bind(this));

    document.body.prepend(this._htmlContent);
  }

  async _fetchData() {
    try {
      if (!this.dataSrc) throw new Error("data source unspecified");

      const response = await fetch(this.dataSrc);

      if (!response.ok) {
        throw new Error(`${response.status}: data could not be fetched`);
      }

      return response.json();
    } catch (err) {
      const errorMessage = document.createElement("li");
      errorMessage.textContent = `${err.message}`;
      this._historyList.append(errorMessage);
    }
  }

  // format date string

  _formatDate(date) {
    return new Date(date).toLocaleString({
      hour12: false,
      timeZone: true,
      timeZoneName: "short",
    });
  }

  async _getSourceHTML(htmlSource) {
    return new Promise((resolve) => {
      // instantiate request class
      const xmlHttpReq = new XMLHttpRequest();

      xmlHttpReq.open("GET", htmlSource);
      xmlHttpReq.onload = () => resolve(xmlHttpReq.responseText);
      xmlHttpReq.onerror = () => resolve(null);

      xmlHttpReq.send();
    });
  }

  //  create and append new "history-list" element for each fetched item

  _populateTemplate(listItems) {
    listItems.forEach((item, i) => {
      // create new element for each list item
      const el = this._createListItem(item);

      // add hide class for all but first four entries
      if (i > 3) {
        el.classList.add("hide");
      }

      // add to dom
      this._historyList.append(el);
    });
  }

  //  toggle expanded history list

  _toggleExpand() {
    // get all history list items
    const historyListItems = [...this._historyList.children];

    // for each, check if in default or expanded group
    historyListItems.forEach((el, i) => {
      if (i > 3) {
        // if hidden by default, check if list is expanded
        if (this.expanded) {
          // hide list + update toggle button text if currently expanded
          el.classList.add("hide");
          this._showAllBtn.textContent = `Show All (${this.data.length})`;
        } else {
          // expand list + update toggle button if currently hidden
          el.classList.remove("hide");
          this._showAllBtn.textContent = "Collapse";
        }
      }
    });

    this.expanded = !this.expanded;
  }
}

// add new custom element of type ArrayCreditLock
customElements.define("array-credit-lock", ArrayCreditLock);
